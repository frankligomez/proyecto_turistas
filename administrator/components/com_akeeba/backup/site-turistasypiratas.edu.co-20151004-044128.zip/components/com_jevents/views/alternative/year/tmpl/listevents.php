<?php 
defined('_JEXEC') or die('Restricted access');

include(JEV_VIEWS."/default/year/tmpl/".basename(__FILE__));
