<?php 
defined('_JEXEC') or die('Restricted access');

include(JEV_VIEWS."/default/icals/tmpl/".basename(__FILE__));
